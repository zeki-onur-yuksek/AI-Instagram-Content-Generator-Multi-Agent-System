# Social Media Content Package

## Contents
- final_post.json: Complete post data with 3 content options
- images/: Processed images optimized for Instagram (1080x1350)

## Usage
1. Choose one of the 3 post options from final_post.json
2. Use the processed images from the images folder
3. Post during recommended hours for maximum engagement

## Post Options
Each option includes:
- Title (max 60 chars)
- Caption (max 2200 chars)
- 12 optimized hashtags

Generated with JoyCase1 Content Pipeline v1.0.0
